import { Component } from '@angular/core';

@Component({
  selector: 'app-login-navbar',
  templateUrl: './login-navbar.component.html',
  styleUrl: './login-navbar.component.scss'
})
export class LoginNavbarComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-perfil-historial-footer',
  standalone: true,
  imports: [],
  templateUrl: './perfil-historial-footer.component.html',
  styleUrl: './perfil-historial-footer.component.scss'
})
export class PerfilHistorialFooterComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-perfil-servicio',
  standalone: true,
  imports: [],
  templateUrl: './perfil-servicio.component.html',
  styleUrl: './perfil-servicio.component.scss'
})
export class PerfilServicioComponent {

}

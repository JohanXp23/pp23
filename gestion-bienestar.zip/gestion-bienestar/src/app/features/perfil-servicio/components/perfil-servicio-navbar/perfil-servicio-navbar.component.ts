import { Component } from '@angular/core';

@Component({
  selector: 'app-perfil-servicio-navbar',
  standalone: true,
  imports: [],
  templateUrl: './perfil-servicio-navbar.component.html',
  styleUrl: './perfil-servicio-navbar.component.scss'
})
export class PerfilServicioNavbarComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-perfil-servicio-filtro',
  standalone: true,
  imports: [],
  templateUrl: './perfil-servicio-filtro.component.html',
  styleUrl: './perfil-servicio-filtro.component.scss'
})
export class PerfilServicioFiltroComponent {

}

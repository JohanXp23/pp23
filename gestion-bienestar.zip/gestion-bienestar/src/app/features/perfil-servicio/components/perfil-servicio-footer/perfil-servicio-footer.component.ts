import { Component } from '@angular/core';

@Component({
  selector: 'app-perfil-servicio-footer',
  standalone: true,
  imports: [],
  templateUrl: './perfil-servicio-footer.component.html',
  styleUrl: './perfil-servicio-footer.component.scss'
})
export class PerfilServicioFooterComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-perfil-servicio-content',
  standalone: true,
  imports: [],
  templateUrl: './perfil-servicio-content.component.html',
  styleUrl: './perfil-servicio-content.component.scss'
})
export class PerfilServicioContentComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-perfil-footer',
  templateUrl: './perfil-footer.component.html',
  styleUrl: './perfil-footer.component.scss'
})
export class PerfilFooterComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-perfil-navbar',
  templateUrl: './perfil-navbar.component.html',
  styleUrl: './perfil-navbar.component.scss'
})
export class PerfilNavbarComponent {

}

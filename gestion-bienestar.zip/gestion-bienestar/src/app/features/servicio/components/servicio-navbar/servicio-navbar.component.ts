import { Component } from '@angular/core';

@Component({
  selector: 'app-servicio-navbar',
  templateUrl: './servicio-navbar.component.html',
  styleUrls: ['./servicio-navbar.component.scss']
})
export class ServicioNavbarComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-servicio-footer',
  templateUrl: './servicio-footer.component.html',
  styleUrl: './servicio-footer.component.scss'
})
export class ServicioFooterComponent {

}

import { Component } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Component({
  selector: "app-registro-form",
  templateUrl: "./registro-form.component.html",
  styleUrls: ["./registro-form.component.scss"],
})
export class RegistroFormComponent {
  registroForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.registroForm = this.fb.group({
      correo: ["", [Validators.required, Validators.email]],
      nombre: ["", [Validators.required, Validators.minLength(3)]],
      apellido: ["", [Validators.required, Validators.minLength(3)]],
      facultad: ["", Validators.required],
      contraseña: ["", [Validators.required, Validators.minLength(6)]],
    });
  }

  onSubmit() {
    if (this.registroForm.valid) {
      console.log("Formulario válido:", this.registroForm.value);
    } else {
      console.log("Formulario inválido");
    }
  }
}

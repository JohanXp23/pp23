import { Component } from '@angular/core';

@Component({
  selector: 'app-registro-navbar',
  templateUrl: './registro-navbar.component.html',
  styleUrl: './registro-navbar.component.scss'
})
export class RegistroNavbarComponent {

}

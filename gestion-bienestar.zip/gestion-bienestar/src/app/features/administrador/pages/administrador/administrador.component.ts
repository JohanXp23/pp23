import { Component, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { parseString } from "xml2js";

interface Servicio {
  id: number;
  servicio: string;
  fecha: string;
  hora: string;
  cupos: number;
  estado: string;
}

@Component({
  selector: "app-administrador",
  templateUrl: "./administrador.component.html",
  styleUrls: ["./administrador.component.scss"],
})
export class AdministradorComponent implements OnInit {
  servicios: Servicio[] = [];
  filteredServicios: Servicio[] = [];
  searchQuery: string = "";

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.cargarServiciosDesdeXML();
  }

  cargarServiciosDesdeXML() {
    this.http
      .get("/assets/models/administrador.xml", { responseType: "text" })
      .subscribe((data) => {
        parseString(data, (err, result) => {
          if (err) {
            console.error("Error al parsear XML", err);
            return;
          }
          // Convertir el resultado a un arreglo de servicios
          this.servicios = result.servicios.servicio.map((servicio: any) => ({
            id: +servicio.id[0],
            servicio: servicio.nombre[0],
            fecha: servicio.fecha[0],
            hora: servicio.hora[0],
            cupos: +servicio.cupos[0],
            estado: servicio.estado[0],
          }));
          this.filteredServicios = [...this.servicios];
        });
      });
  }

  filterServicios() {
    this.filteredServicios = this.servicios.filter((servicio) =>
      servicio.servicio.toLowerCase().includes(this.searchQuery.toLowerCase())
    );
  }

  eliminarServicio(id: number) {
    this.servicios = this.servicios.filter((servicio) => servicio.id !== id);
    this.filterServicios(); // Actualiza el filtro
  }

  editarServicio(servicio: Servicio) {
    alert(`Editando servicio: ${servicio.servicio}`);
  }

  crearServicio() {
    alert("Creando nuevo servicio");
  }
}
